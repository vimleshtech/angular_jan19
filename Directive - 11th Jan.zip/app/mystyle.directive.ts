import { Directive,ElementRef,HostListener } from '@angular/core';

@Directive({
  selector: '[appMystyle]'
})
export class MystyleDirective {

  constructor(private el:ElementRef) { 
    
    el.nativeElement.style.color="red";
    el.nativeElement.style.backgroundColor="yellow";
    el.nativeElement.innerHTML="Test data....";

  }

  @HostListener('mouseenter')
  onMouseEnter()
  {
    	this.highlight('red','white');
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.highlight('white','black');
    
  	}

    
  private highlight(color: string,fc:string) {
      this.el.nativeElement.style.backgroundColor = color;
      this.el.nativeElement.style.color = fc;
  }

    
}
