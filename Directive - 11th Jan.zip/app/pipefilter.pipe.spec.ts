import { PipefilterPipe } from './pipefilter.pipe';

describe('PipefilterPipe', () => {
  it('create an instance', () => {
    const pipe = new PipefilterPipe();
    expect(pipe).toBeTruthy();
  });
});
