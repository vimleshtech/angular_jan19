import { Directive,ElementRef,HostListener,Input } from '@angular/core';

@Directive({
  selector: '[appWithargument]'
})
export class WithargumentDirective {

  constructor(private el : ElementRef) { 

  }
  
  @Input('test') 
  test: string; 
  
  
  @Input('cd') 
  cd: string; 
  

  @HostListener('mouseenter') 
  onMouseEnter() { 

    console.log(this.test);
    console.log(this.cd);

    this.highlight(this.test || 'red'); 
  } 
  
  @HostListener('mouseleave') 
  onMouseLeave() { 
    this.highlight(null); 
  
  } 
  
  private highlight(color: string) { 
    
    this.el.nativeElement.style.backgroundColor = color; 
  
  } 


}
