import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-servicecall',
  templateUrl: './servicecall.component.html',
  styleUrls: ['./servicecall.component.css']
})
export class ServicecallComponent implements OnInit {

  status='';
  obj;
  constructor() { 

    
    this.obj = new MyserviceService("","active");


  }

  clickTest()
  {

    
    this.status = this.obj.toggleState();
    console.log(this.status);


  }
  ngOnInit() {
  }

}
