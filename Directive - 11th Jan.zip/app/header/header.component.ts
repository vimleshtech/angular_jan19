import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  isLoggedIn = false;
  isNewUser=true;
  header='Piple Test';

  birthday = new Date(1988, 3, 15);
  data =[1111,222,11,22,999,3331,2,3];

  emps=[{id:1,name:'raman',gender:'male'},
    {id:11,name:'monika',gender:'female'},
    {id:3,name:'jatin',gender:'male'}];

  constructor() { }

  ngOnInit() {
  }

}
