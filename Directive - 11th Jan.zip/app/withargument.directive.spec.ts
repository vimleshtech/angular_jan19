import { WithargumentDirective } from './withargument.directive';

describe('WithargumentDirective', () => {
  it('should create an instance', () => {
    const directive = new WithargumentDirective();
    expect(directive).toBeTruthy();
  });
});
