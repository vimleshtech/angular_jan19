import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent  {

  pid;
  pname;
  price;
  quatnity;
  eind=-1
  products=[]


  constructor()  {
        this.clear()
        this.products=[]
  }
  
  clear(){
    this.pid =''
      this.pname=''
      this.price=''
      this.quatnity =''
      
  }
  setID(event){

       this.pid = event.target.value;

  }

  setName(event){
    this.pname = event.target.value;

  }
  
  setPrice(event){
    
    this.price = event.target.value;

  }
  
  setQuantity(event){
    this.quatnity = event.target.value;
  }
  
  AddProduct(){

      this.products.push({'pid':this.pid,'pname':this.pname,'price':this.price,'qty':this.quatnity,'isMark':false});

      this.clear()

      console.log(this.products);

  }

  updateProduct(){

      if(this.eind>-1)
      {
        this.products[this.eind].pid = this.pid
        this.products[this.eind].pname =this.pname  
        this.products[this.eind].price =this.price
        this.products[this.eind].qty =this.quatnity


        this.clear()
        this.eind =-1

      }

      /*
      for(let i=0;i<this.products.length;i++)
      {
          if(this.products[i].pid == this.pid)
          {
            this.products[this.eind].pname =this.pname  
            this.products[this.eind].price =this.price
            this.products[this.eind].qty =this.quatnity
          }
      }
      */

  }
  editRow(ind)
  {
   
      this.pid  = this.products[ind].pid
      this.pname  = this.products[ind].pname
      this.price  = this.products[ind].price
      this.quatnity  = this.products[ind].qty
      this.eind = ind 
  }
  markRow(ind)
  {
    this.products[ind].isMark = !this.products[ind].isMark

  }
  delRow(ind)
  {
      //alert(ind);
      this.products.splice(ind,1);

  }

}
