import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { HeaderComponent } from './header/header.component';
import { PipesortPipe } from './pipesort.pipe';
import { PipefilterPipe } from './pipefilter.pipe';
import { MystyleDirective } from './mystyle.directive';
import { WithargumentDirective } from './withargument.directive';
import { ServicecallComponent } from './servicecall/servicecall.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    HeaderComponent,
    PipesortPipe,
    PipefilterPipe,
    MystyleDirective,
    WithargumentDirective,
    ServicecallComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
