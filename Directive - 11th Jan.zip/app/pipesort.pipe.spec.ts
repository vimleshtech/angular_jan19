import { PipesortPipe } from './pipesort.pipe';

describe('PipesortPipe', () => {
  it('create an instance', () => {
    const pipe = new PipesortPipe();
    expect(pipe).toBeTruthy();
  });
});
