import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipesort'
})
export class PipesortPipe implements PipeTransform {

  transform(value: any, args?: any, arg1?: number, arg2?: number,arg3?: any): any 
  {


    if(arg1 != null )
    {
      var a = this.add(arg1,arg2);
      //alert(arg1);
      //alert(arg2);

      value.push(a);
      //alert(a);

    }
    if(arg3!=null)
    {
        var f1 = arg3[0].gender;
        var f2 = arg3[0].sal;
        
    }
    if(args =='desc')
    {
      
      return value.sort().reverse();
    }
    else{
      
      return value.sort();
    }
    
  }

  add(a,b)
  {
    return a+b;
  }

}
