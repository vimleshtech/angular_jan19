import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'pipefilter'
})
export class PipefilterPipe implements PipeTransform {

  transform(value: any, args?: any): any 
  {

    if(args != null)
    {
      //alert(args);
      var d =value.filter(x => x.gender == args);;
      //alert(d);

        return d;

        

    }
    else 
    {
        return value;
    }
  }

}
