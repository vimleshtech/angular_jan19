import { Component, Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent  {

  count = 0;
  
      increment() {
         this.count++;
       }
     decrement() {
         this.count--;
     }
     
  
    // @Input() count: number;
  
    //  @Output() countChanged: EventEmitter<number> =   new EventEmitter();
  
    //  increment() {
    //      this.count++;
    //      this.countChanged.emit(this.count);
    //    }
    //  decrement() {
    //      this.count--;
    //      this.countChanged.emit(this.count);
    //  }


}
