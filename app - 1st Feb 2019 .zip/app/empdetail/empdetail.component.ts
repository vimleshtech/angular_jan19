import { Component, OnInit } from '@angular/core';

import { ActivatedRoute,Router  } from '@angular/router';
import { Location } from '@angular/common';


@Component({
  selector: 'app-empdetail',
  templateUrl: './empdetail.component.html',
  styleUrls: ['./empdetail.component.css']
})
export class EmpdetailComponent implements OnInit {

  constructor( private route: ActivatedRoute,    
    private location: Location
  ,private router: Router) { }

    ngOnInit(): void {
      const id = +this.route.snapshot.paramMap.get('id');
      console.log(id);
    }
    
    getHero(): void {

      
 
      //go back
      //this.location.back();

    }

    btnClick() {
      
      this.router.navigateByUrl('/home');
  }
}
