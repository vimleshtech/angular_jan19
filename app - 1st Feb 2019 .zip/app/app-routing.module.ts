import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { EmployeeComponent }      from './employee/employee.component';
import { HomeComponent }      from './home/home.component';
import {EmpdetailComponent}  from './empdetail/empdetail.component';


const routes: Routes = [{path: 'home', component: HomeComponent}
                        ,{path: 'employee', component: EmployeeComponent}
                        ,{ path: '', redirectTo: '/employee', pathMatch: 'full' },
                        { path: 'empdetail/:id', component: EmpdetailComponent }
                         ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
