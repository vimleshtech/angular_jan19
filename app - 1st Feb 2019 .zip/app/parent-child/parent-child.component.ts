import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent-child',
  templateUrl: './parent-child.component.html',
  styleUrls: ['./parent-child.component.css']
})
export class ParentChildComponent {

  data

  constructor(){

    this.data=[];
  }

  changeData() {

    //alert('test');

    this.data.push(100);
    console.log(this.data);    

 }

}
