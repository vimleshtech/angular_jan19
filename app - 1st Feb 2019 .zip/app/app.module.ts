import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { EmployeeComponent } from './employee/employee.component';
import { MessagesComponent } from './messages/messages.component';
import { EmpdetailComponent } from './empdetail/empdetail.component';
import { ChildComponent } from './child/child.component';
import { ParentChildComponent } from './parent-child/parent-child.component';
import { ParentToChildComponent } from './parent-to-child/parent-to-child.component';
import { ParentComponent } from './parent/parent.component';
import { SiblingsComponent } from './siblings/siblings.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    EmployeeComponent,
    MessagesComponent,
    EmpdetailComponent,
    ChildComponent,
    ParentChildComponent,
    ParentToChildComponent,
    ParentComponent,
    SiblingsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
