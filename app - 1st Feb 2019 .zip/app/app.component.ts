
import { Component,ViewChild } from '@angular/core';

import { ChildComponent } from './child/child.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  title = 'Component Interaction';
  Counter = 5;
  @ViewChild(ChildComponent) child: ChildComponent;


  // countChangedHandler(count: number) {
  //   this.Counter = count;
  //   console.log(count);
  // }

  increment() {
    this.child.increment();
  }
 
  decrement() {
    this.child.decrement();
  }


  ngAfterViewInit() {
   // this.message = this.child.message
  }


}
