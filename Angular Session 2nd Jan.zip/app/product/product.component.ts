import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent  {

  pid;
  pname;
  price;
  quatnity;
  products:[]

  constructor()  {
      this.pid =0
      this.pname=''
      this.price=0
      this.quatnity =0      
      this.products=[]
  }
  
  setID(event){

       this.pid = event.target.value;

  }

  setName(event){
    this.pname = event.target.value;

  }
  
  setPrice(event){
    
    this.price = event.target.value;

  }
  
  setQuantity(event){
    this.quatnity = event.target.value;
  }
  
  AddProduct(){

      this.products.push({'pid':this.pid,'pname':this.pname,'price':this.price,'qty':this.quatnity});

      console.log(this.products);

  }
  delRow(ind)
  {
      //alert(ind);
      this.products.splice(ind,1);

  }

}
