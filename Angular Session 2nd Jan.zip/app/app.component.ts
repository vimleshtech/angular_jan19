import { Component } from '@angular/core';

//@Component : annotation 

@Component({
  
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css','./app.component.2.css']

})
export class AppComponent {

  //declare the variables
  name:string
  id:number;
  user:string='Raman Sinha'
  emailid='raman@gmail.com'




}
