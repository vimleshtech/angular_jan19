import { CustdirDirective } from './custdir.directive';

describe('CustdirDirective', () => {
  it('should create an instance', () => {
    const directive = new CustdirDirective();
    expect(directive).toBeTruthy();
  });
});
