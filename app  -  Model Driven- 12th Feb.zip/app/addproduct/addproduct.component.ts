import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {

  name ="test name"
  aa="raman,jatin";

  constructor() { }

  takeName(event)
  {
      this.name = event.target.value 

      localStorage.clear();//remove all
      //localStorage.removeItem("empname"); //remove key
      localStorage.setItem("empname",this.name);
      localStorage.setItem("id","111");

      console.log(localStorage.getItem("empname"));


      
  }
  ngOnInit() {
  }

}
