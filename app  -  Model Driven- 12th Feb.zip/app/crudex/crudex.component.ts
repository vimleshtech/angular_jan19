import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crudex',
  templateUrl: './crudex.component.html',
  styleUrls: ['./crudex.component.css']
})
export class CrudexComponent {

  id
  name
  sal 
  emps
  constructor() { 

    this.emps =[]
  }

  takeId(event)
  {
    this.id  = event.target.value 
  }
  takeNa(event)
  {
    this.name  = event.target.value 
  }
  takeSa(event)
  {
    this.sal  = event.target.value 

  }
  addEm()
  {
    this.emps.push({id:this.id,name:this.name,sal:this.sal})
    
  }
  delEmp(i)
  {
    
    this.emps.splice(i,1);
    
  }
  sortByName()
  {
    this.emps = this.emps.sort((a,b)=> a.name.localeCompare(b.name))
    
  }
}
