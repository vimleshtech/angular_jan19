export class Compute{

    addNum(a,b)
    {
        return a+b;
    }

    addMul(a,b)
    {
        return a*b;
    }
    
}