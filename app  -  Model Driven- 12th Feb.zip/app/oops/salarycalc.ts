import {Compute} from './compute'

interface sample{

    add(a,b);
    mul(a,b);    
    div(a);

}
export class SalaryCal extends Compute implements sample
{
    add(a,b){
        return a+b

    }
    mul(a,b){
        return a*b
    }   
    div(a){
        return a
    }

    yearlySal(sal)
    {
        var ysal = sal*12 ;
       return this.addNum(ysal,ysal*.10) ;

    }

  

}
