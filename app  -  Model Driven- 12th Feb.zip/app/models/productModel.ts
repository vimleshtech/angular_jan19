export class productModel
{
    pid:number
    pname:string
    pprice:number
    isMarked:boolean

    constructor(pid,pname,pprice) {
        this.pid =pid;
        this.pname =pname;
        this.pprice =pprice;
        this.isMarked =false;
    }

    toogle()
    {
        this.isMarked = !this.isMarked;
    }


}
