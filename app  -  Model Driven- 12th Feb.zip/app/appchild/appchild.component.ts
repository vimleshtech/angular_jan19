import { Component,OnInit, EventEmitter,Output } from '@angular/core';

@Component({
  selector: 'app-appchild',
  templateUrl: './appchild.component.html',
  styleUrls: ['./appchild.component.css']
})
export class AppchildComponent implements OnInit {

  @Output() valueChange = new EventEmitter();
  counter = 0;
  childname=''
  name=''

  takeName(event){
      this.name = event.target.value;

  }

  valueChanged() { // You can give any function name

      this.counter = this.counter + 1;
      this.childname=this.name;
      this.valueChange.emit(this.counter);
      
  }

  constructor() { }

  ngOnInit() {
  }

}
