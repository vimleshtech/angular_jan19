import { Directive,ElementRef,HostListener  } from '@angular/core';

@Directive({
  selector: '[appMydesign]'
})
export class MydesignDirective {

  el 
  msg ='This is test directive'
  constructor(ele:ElementRef) {
    
    this.el = ele.nativeElement;
    ele.nativeElement.style.color ="red";
    ele.nativeElement.style.backgroundColor="yellow";
    ele.nativeElement.innerHTML=this.msg;

   }
   

    
   @HostListener('mouseenter') 
   onMouseEnter() 
   {
      this.el.style.backgroundColor="black";
      this.el.innerHTML = this.msg+" | Element is active now";
   }
    
   @HostListener('mouseleave') 
   onMouseLeave() 
   {
      this.el.style.backgroundColor="yellow";
      this.el.innerHTML = this.msg;
      
   }
   

}
