import { Component } from '@angular/core';

@Component({
  selector: 'app-dtype',
  templateUrl: './dtype.component.html',
  styleUrls: ['./dtype.component.css']
})

export class DtypeComponent  {

  /*data type in typescript:
  1. number : 1111,   4444.33
  2. string  : '' or "skjsjhgs
  3. boolean : true/false
  4. object   : [11,22,,33]   or {id:222,name:'raman'}
  5. function    : a = function test(){ }
                a()

  6. other/default : any 
  */

  //declare data variable
  name      //default data type is any 
  nname:any //data type is any 
  address:string
  id:number
  status:boolean

  constructor() { 
    this.name = 'test name';
    this.nname ='test nname'
    this.address ='test address'
    this.id=111
    this.status =true;
  }

}
