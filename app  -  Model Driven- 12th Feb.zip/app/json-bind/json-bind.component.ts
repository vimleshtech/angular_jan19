import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-json-bind',
  templateUrl: './json-bind.component.html',
  styleUrls: ['./json-bind.component.css']
})
export class JsonBindComponent implements OnInit {

  emps 
  fn
  ln 
  constructor() {


    this.emps =[]

   }

   takefn(event){
     this.fn = event.target.value
   }


   takeln(event){
    this.ln = event.target.value
  }

  addEmp(){

    this.emps.push({fn:this.fn,ln:this.ln})

    console.log(this.emps)
  }

  del(ind)
  {
    this.emps.splice(ind,1)
  }
  ngOnInit() {
  }

}
