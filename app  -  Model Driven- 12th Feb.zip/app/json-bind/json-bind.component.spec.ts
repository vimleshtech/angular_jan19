import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JsonBindComponent } from './json-bind.component';

describe('JsonBindComponent', () => {
  let component: JsonBindComponent;
  let fixture: ComponentFixture<JsonBindComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JsonBindComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JsonBindComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
