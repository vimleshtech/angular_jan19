
import { TestBed, async } from '@angular/core/testing';
import { MyPipe } from './my.pipe';

describe('MyPipe', () => {

  it('create an instance', () => {
    const pipe = new MyPipe();
    //   let pipe = new MyPipe();
    expect(pipe).toBeTruthy();
  });

});
