import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css']
})
export class CrudComponent implements OnInit {

  name=''
  email =''
  mark=false
  emps=[]
  memps=[]
  i
  tcount
  tmark
  tunmark
  sname
  
  constructor() { 
    this.tcount=0
    this.tmark=0
    this.tunmark=0
  }

  ngOnInit() {
  }

  takeName(event)
  {
  this.name = event.target.value
  
  }
  takesname(event)
  {
  this.sname = event.target.value
  
  }
  takeEmail(event)
  {
    this.email   = event.target.value
  }
  addRow()
  {
    this.emps.push({name:this.name,email:this.email})
    this.countrow();
    this.emps[this.emps.length-1].mark=false
    this.memps=this.emps  
  }
  countrow()
  { var j
    this.tcount=0;
    this.tmark=0;
    for(j=0;j<this.emps.length;j++)
    {
      this.tcount++;
      if(this.emps[j].mark==true)
      {
        this.tmark++;
      }
    }
    this.tunmark=this.tcount-this.tmark;
  }
  updateRow()
  {
      this.emps[this.i].name = this.name
      this.emps[this.i].email = this.email
  }
  editRow(ind)
  {
        this.i =ind
        this.name = this.emps[ind].name
        this.email = this.emps[ind].email
  }
  markRow(ind)
  {
    this.emps[ind].mark=!this.emps[ind].mark;
    this.countrow();
  }
  delRow()
  {
    this.emps=this.emps.filter(a=>a.mark==false)
    this.countrow()
  }
  search()
  {
    this.emps=this.memps.filter(a=>a.name==this.sname)
  }
  showall()
  {
    this.emps=this.memps
  }

}
