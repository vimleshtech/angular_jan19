import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelValidateComponent } from './model-validate.component';

describe('ModelValidateComponent', () => {
  let component: ModelValidateComponent;
  let fixture: ComponentFixture<ModelValidateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModelValidateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelValidateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
