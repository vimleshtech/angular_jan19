export class Proudct
{
    //data members 
    pid;
    pname;
    price;

    //functions : constructor 
    constructor(pid,pname,price)
    {
        this.pid =pid;
        this.pname=pname;
        this.price = 	price;	

    }
}