import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommonFunService {

  constructor() { }


  add(a,b){ 
    return a+b;
  }

  tax(amt)
  {
      var tax=0;
      if(amt>10000)
      {
        tax = amt*.18;
      }
      else
      {
        tax = amt*.10;
      }

      return amt+tax;
  }

}
